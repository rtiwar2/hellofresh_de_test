from pyspark.sql import SparkSession
from etl.extract.extract import Extract
from etl.transform.transform import Transform
from etl.load.load import Load
import sys
import resources.config
import logging.config

if __name__ == '__main__':
    logging.config.fileConfig("C:/Users/Lenovo/PycharmProjects/HelloFreshProject/resources/config/logging.conf")

    logging.info("creating spark session")
    spark = SparkSession.builder.appName("HelloFreshSparkETL").getOrCreate()

    input_data_path = "C:/Users/Lenovo/PycharmProjects/HelloFreshProject/resources/input/"
    output_data_path = "E:/python_output/output_data"

    logging.info("input_data_pathn: "+input_data_path)
    logging.info("output_data_path: " + output_data_path)

    logging.info("Invoking extractor")
    input_df = Extract().extracter(spark, input_data_path)

    logging.info("Invoking transformer")
    transform_df = Transform().transformer(spark, input_df)

    logging.info("Invoking loader")
    Load().loader(spark, transform_df, output_data_path)

    logging.info("end of main function i.e. application")


