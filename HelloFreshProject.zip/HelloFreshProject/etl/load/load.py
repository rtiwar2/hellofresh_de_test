import logging.config


class Load:
    def loader(self, spark, transform_df, output_data_path):
        logging.config.fileConfig("C:/Users/Lenovo/PycharmProjects/HelloFreshProject/resources/config/logging.conf")
        logging.info("Inside Load.loader() function")

        transform_df.write.mode("overwrite").csv(output_data_path)

        logging.info("End of Load.loader() function")
